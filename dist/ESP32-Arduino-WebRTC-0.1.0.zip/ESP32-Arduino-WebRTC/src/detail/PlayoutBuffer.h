#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
#include "G711.h"
namespace arduino_webrtc {
// Single lock supplied by the caller. Timestamps are milliseconds, as in esp_peer.
// A fixed sample timeline accepts 10..120 ms PCMU packets, gaps and reordering.
class PlayoutBuffer {
public:
    static constexpr size_t frameSamples = 160;
    static constexpr size_t capacity = 1600;
    struct Counters { uint32_t late = 0, resync = 0, missingSamples = 0; } counters;
    void reset(unsigned prefillMs = 60) {
        std::memset(valid_, 0, sizeof(valid_));
        read_ = high_ = 0; head_ = 0; primed_ = started_ = false;
        target_ = prefillMs * 8; last_ = 0; emptyFrames_ = 0;
    }
    bool push(uint32_t pts, const uint8_t* bytes, size_t count) {
        if (!bytes || !count || count > 960) return false;
        const uint32_t start = pts * 8u;
        if (!primed_) { read_ = high_ = start; primed_ = true; }
        int32_t offset = static_cast<int32_t>(start - read_);
        if (offset + static_cast<int32_t>(count) <= 0) { ++counters.late; return false; }
        if (offset > static_cast<int32_t>(capacity) || offset + static_cast<int32_t>(count) > static_cast<int32_t>(capacity)) {
            // Bound latency after long stalls/clock drift. Never expand storage.
            reset(target_ / 8); ++counters.resync;
            read_ = high_ = start; primed_ = true; offset = 0;
        }
        for (size_t i = 0; i < count; ++i) {
            int32_t at = offset + static_cast<int32_t>(i);
            if (at < 0) continue;
            size_t slot = (head_ + static_cast<size_t>(at)) % capacity;
            samples_[slot] = decodeMuLaw(bytes[i]); valid_[slot] = true;
        }
        uint32_t end = start + static_cast<uint32_t>(count);
        if (static_cast<int32_t>(end - high_) > 0) high_ = end;
        return true;
    }
    // Always fills one frame. Missing samples fade to silence; no last-packet loop.
    bool pop(int16_t* out) {
        if (!primed_ || (!started_ && static_cast<int32_t>(high_ - read_) < static_cast<int32_t>(target_))) {
            std::memset(out, 0, frameSamples * sizeof(int16_t)); return false;
        }
        started_ = true;
        unsigned present = 0;
        for (size_t i = 0; i < frameSamples; ++i) {
            if (valid_[head_]) { last_ = samples_[head_]; ++present; }
            else { last_ = static_cast<int16_t>(last_ * 31 / 32); ++counters.missingSamples; }
            out[i] = last_; valid_[head_] = false;
            head_ = (head_ + 1) % capacity; ++read_;
        }
        emptyFrames_ = present ? 0 : emptyFrames_ + 1;
        // Rebuffer after a sustained outage; silence is still written to DMA.
        if (emptyFrames_ >= 5) { reset(target_ / 8); ++counters.resync; }
        return true;
    }
private:
    int16_t samples_[capacity]{};
    bool valid_[capacity]{};
    uint32_t read_ = 0, high_ = 0;
    size_t head_ = 0, target_ = 480;
    unsigned emptyFrames_ = 0;
    bool primed_ = false, started_ = false;
    int16_t last_ = 0;
};
}
