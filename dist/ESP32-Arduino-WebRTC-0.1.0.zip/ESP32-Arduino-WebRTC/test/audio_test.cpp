#include "detail/G711.h"
#include "detail/Fingerprint.h"
#include <string>
#include "detail/PlayoutBuffer.h"
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
using namespace arduino_webrtc;
int main() {
    assert(encodeMuLaw(0) == 0xff);
    assert(decodeMuLaw(0xff) == 0 && decodeMuLaw(0x7f) == 0);
    assert(decodeMuLaw(0x80) == 32124 && decodeMuLaw(0x00) == -32124);
    assert(encodeMuLaw(-32768) == 0 && encodeMuLaw(32767) == 0x80);
    for (int v = -32768; v <= 32767; ++v) assert(std::abs(v - decodeMuLaw(encodeMuLaw(v))) <= 644);
    for (int u = 0; u < 256; ++u) if (u != 0x7f) assert(encodeMuLaw(decodeMuLaw(u)) == u);
    PlayoutBuffer b; b.reset();
    uint8_t packet[960]; std::fill_n(packet,960,encodeMuLaw(1000));
    int16_t out[160];
    assert(!b.pop(out)); assert(out[0] == 0);
    assert(!b.push(0,nullptr,160)); assert(!b.push(0,packet,961));
    assert(b.push(0,packet,160)); assert(!b.pop(out));
    assert(b.push(40,packet,160)); assert(b.push(20,packet,160));
    for (int i=0;i<3;++i) { assert(b.pop(out)); assert(out[0] == decodeMuLaw(packet[0])); }
    assert(!b.push(0,packet,160)); assert(b.counters.late == 1);
    b.pop(out); assert(out[159] < 10); assert(b.counters.missingSamples == 160);
    for (int i=0;i<4;++i) b.pop(out);
    assert(!b.pop(out)); assert(b.counters.resync == 1);
    b.reset(20); b.push(0,packet,160); b.pop(out);
    b.push(10000,packet,160); assert(b.counters.resync == 2); assert(b.pop(out));
    // PTS wrap (ms) and ring wrap, including a packet spanning both.
    b.reset(20); uint32_t stamp = UINT32_MAX - 19;
    for (int i=0;i<1000;++i) { assert(b.push(stamp,packet,160)); assert(b.pop(out)); assert(out[159] == decodeMuLaw(packet[0])); stamp += 20; }
    // Variable packetization and duplicates preserve sample order.
    b.reset(20); b.push(0,packet,80); assert(!b.pop(out)); b.push(10,packet,80); b.push(10,packet,80);
    assert(b.pop(out)); assert(out[159] == decodeMuLaw(packet[0]));
    b.reset(20); b.push(0,packet,960); for(int i=0;i<6;++i) { assert(b.pop(out)); assert(out[159] == decodeMuLaw(packet[0])); }
    uint8_t digest[32];
    std::string fp = "a=fingerprint:sha-256 ";
    for (int i=0;i<32;++i) { if(i) fp += ':'; fp += "AB"; }
    assert(parseFingerprint((fp+"\r\n").c_str(),fp.size()+2,digest));
    assert(digest[0]==0xab && digest[31]==0xab);
    assert(!parseFingerprint(fp.c_str(),fp.size()-1,digest));
    std::string repeated=fp+"\n"+fp+"\n";
    assert(parseFingerprint(repeated.c_str(),repeated.size(),digest));
    repeated[repeated.size()-2]='0';
    assert(!parseFingerprint(repeated.c_str(),repeated.size(),digest));
    assert(!parseFingerprint("v=0\r\n",5,digest));
    std::string embedded=fp+std::string(1,'\0')+"ignored";
    assert(!parseFingerprint(embedded.c_str(),embedded.size(),digest));
    puts("PASS: SDP fingerprint validation");
    puts("PASS: G.711 exhaustive roundtrip, bounded playout, reordering, loss, duplicates, outage, overflow, PTS wrap");
}
